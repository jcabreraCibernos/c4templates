#!/bin/bash

ln -s /cms/composer.json /var/www/cms
ln -s /cms/composer.lock /var/www/cms
ln -s /cms/patches /var/www/cms
cd /var/www/cms && composer install
rm /var/www/cms/web/sites/default/settings.php
ln -s /cms/web/sites/default/settings.php /var/www/cms/web/sites/default/settings.php
ln -s /cms/web/sites/default/settings.local.php /var/www/web/cms/sites/default/settings.local.php
mkdir /var/www/cms/web/sites/default/files && chmod -R 777 /var/www/cms/web/sites/default/files

cd /var/www/cms && vendor/drush/drush/drush si  --root=/var/www/cms -y
cd /var/www/cms && vendor/drush/drush/drush  en ckan_connect --root=/var/www/cms
cd /var/www/cms && vendor/drush/drush/drush  upwp "admin"  "admin" --root=/var/www/cms -y
cd /var/www/cms && vendor/drush/drush/drush  cr
ln -s /cms/web/modules/custom/ /var/www/cms/web/modules/
ln -s /cms/web/config/ /var/www/cms/
cd /var/www/cms && vendor/drush/drush/drush entity:delete shortcut -y --root=/var/www/cms 
cd /var/www/cms && vendor/drush/drush/drush pmu shortcut -y --root=/var/www/cms 
cd /var/www/cms && vendor/drush/drush/drush cset system.site uuid "f0628320-621a-4c08-808f-ac882a4243a" --root=/var/www/cms  -y
cd /var/www/cms && vendor/drush/drush/drush cim -y --root=/var/www/cms 




{
  "": {
    "domain": "ckan", 
    "lang": "km", 
    "plural-forms": "nplurals=1; plural=0;"
  }, 
  "Image": [
    null, 
    "រូបភាព"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    ""
  ]
}
{
  "": {
    "domain": "ckan", 
    "lang": "en_GB", 
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }, 
  "Add Filter": [
    null, 
    "Add Filter"
  ], 
  "An Error Occurred": [
    null, 
    "An Error Occurred"
  ], 
  "Are you sure you want to perform this action?": [
    null, 
    "Are you sure you want to perform this action?"
  ], 
  "Cancel": [
    null, 
    "Cancel"
  ], 
  "Confirm": [
    null, 
    "Confirm"
  ], 
  "Could not load view": [
    null, 
    "Could not load view"
  ], 
  "DataProxy returned an error": [
    null, 
    "DataProxy returned an error"
  ], 
  "DataStore returned an error": [
    null, 
    "DataStore returned an error"
  ], 
  "Edit": [
    null, 
    "Edit"
  ], 
  "Failed to load data API information": [
    null, 
    "Failed to load data API information"
  ], 
  "File": [
    null, 
    "File"
  ], 
  "Filters": [
    null, 
    "Filters"
  ], 
  "Follow": [
    null, 
    "Follow"
  ], 
  "Graph": [
    null, 
    "Graph"
  ], 
  "Grid": [
    null, 
    "Grid"
  ], 
  "Hide": [
    null, 
    "Hide"
  ], 
  "Image": [
    null, 
    "Image"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "Input is too short, must be at least one character", 
    "Input is too short, must be at least %(num)d characters"
  ], 
  "Link": [
    null, 
    "Link"
  ], 
  "Link to a URL on the internet (you can also link to an API)": [
    null, 
    "Link to a URL on the internet (you can also link to an API)"
  ], 
  "Loading...": [
    null, 
    "Loading..."
  ], 
  "Map": [
    null, 
    "Map"
  ], 
  "No matches found": [
    null, 
    "No matches found"
  ], 
  "Please Confirm Action": [
    null, 
    "Please Confirm Action"
  ], 
  "Remove": [
    null, 
    "Remove"
  ], 
  "Resource uploaded": [
    null, 
    "Resource uploaded"
  ], 
  "Save order": [
    null, 
    "Save order"
  ], 
  "Saving...": [
    null, 
    "Saving..."
  ], 
  "Select a field": [
    null, 
    "Select a field"
  ], 
  "Show more": [
    null, 
    "Show more"
  ], 
  "Start typing…": [
    null, 
    "Start typing…"
  ], 
  "There are unsaved modifications to this form": [
    null, 
    "There are unsaved modifications to this form"
  ], 
  "There is no API data to load for this resource": [
    null, 
    "There is no API data to load for this resource"
  ], 
  "URL": [
    null, 
    "URL"
  ], 
  "Unable to authenticate upload": [
    null, 
    "Unable to authenticate upload"
  ], 
  "Unable to get data for uploaded file": [
    null, 
    "Unable to get data for uploaded file"
  ], 
  "Unable to upload file": [
    null, 
    "Unable to upload file"
  ], 
  "Unfollow": [
    null, 
    "Unfollow"
  ], 
  "Upload": [
    null, 
    "Upload"
  ], 
  "Upload a file": [
    null, 
    "Upload a file"
  ], 
  "Upload a file on your computer": [
    null, 
    "Upload a file on your computer"
  ], 
  "You are uploading a file. Are you sure you want to navigate away and stop this upload?": [
    null, 
    "You are uploading a file. Are you sure you want to navigate away and stop this upload?"
  ], 
  "error loading view": [
    null, 
    "error loading view"
  ]
}
{
  "": {
    "domain": "ckan", 
    "lang": "fa_IR", 
    "plural-forms": "nplurals=2; plural=(n > 1);"
  }, 
  "Filters": [
    null, 
    "فیلترها"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    ""
  ], 
  "Map": [
    null, 
    "نقشه"
  ]
}
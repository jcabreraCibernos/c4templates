{
  "": {
    "domain": "ckan", 
    "lang": "gl", 
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }, 
  "Could not load view": [
    null, 
    "Non foi posíbel cargar a vista"
  ], 
  "DataProxy returned an error": [
    null, 
    "O proxy de datos devolveu un erro"
  ], 
  "DataStore returned an error": [
    null, 
    "O almacén de datos devolveu un erro"
  ], 
  "Filters": [
    null, 
    "Filtros"
  ], 
  "Graph": [
    null, 
    "Gráfico"
  ], 
  "Grid": [
    null, 
    "Grella"
  ], 
  "Image": [
    null, 
    "Imaxe"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    ""
  ], 
  "Loading...": [
    null, 
    "Loading..."
  ], 
  "Map": [
    null, 
    "Mapa"
  ], 
  "error loading view": [
    null, 
    "produciuse un erro ao cargar a vista"
  ]
}
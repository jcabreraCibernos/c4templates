{
  "": {
    "domain": "ckan", 
    "lang": "id", 
    "plural-forms": "nplurals=1; plural=0;"
  }, 
  "Cancel": [
    null, 
    "Batal"
  ], 
  "Edit": [
    null, 
    "Edit"
  ], 
  "Follow": [
    null, 
    "Ikuti"
  ], 
  "Graph": [
    null, 
    "Grafik"
  ], 
  "Image": [
    null, 
    "Gambar"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    ""
  ], 
  "Loading...": [
    null, 
    "Memuat..."
  ], 
  "Map": [
    null, 
    "Peta"
  ], 
  "URL": [
    null, 
    "URL"
  ], 
  "Unfollow": [
    null, 
    "Tidak ikuti"
  ], 
  "Upload": [
    null, 
    "Unggah"
  ], 
  "Upload a file": [
    null, 
    "Unggah file"
  ], 
  "error loading view": [
    null, 
    "Kesalahan dalam memuat pratayang"
  ]
}
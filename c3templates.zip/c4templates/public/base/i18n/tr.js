{
  "": {
    "domain": "ckan", 
    "lang": "tr", 
    "plural-forms": "nplurals=2; plural=(n > 1);"
  }, 
  "Add Filter": [
    null, 
    "Filtre ekle"
  ], 
  "An Error Occurred": [
    null, 
    "Hata oluştu"
  ], 
  "Confirm": [
    null, 
    "Onayla"
  ], 
  "Edit": [
    null, 
    "Düzenle"
  ], 
  "Filters": [
    null, 
    "Filtreler"
  ], 
  "Graph": [
    null, 
    "Grafik"
  ], 
  "Hide": [
    null, 
    "Gizle"
  ], 
  "Image": [
    null, 
    "Resim"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    ""
  ], 
  "Loading...": [
    null, 
    "Yükleniyor..."
  ], 
  "Map": [
    null, 
    "Harita"
  ], 
  "No matches found": [
    null, 
    "Eşleşme bulunamadı"
  ], 
  "Saving...": [
    null, 
    "Kaydediliyor..."
  ]
}
<?php

namespace Drupal\cb_flag\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Flag cb entity entities.
 *
 * @ingroup cb_flag
 */
class FlagCbEntityDeleteForm extends ContentEntityDeleteForm {


}

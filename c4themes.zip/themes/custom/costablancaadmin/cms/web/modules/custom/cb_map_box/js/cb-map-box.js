(function ($, Drupal, drupalSettings) {

    mapboxgl.accessToken = 'pk.eyJ1Ijoiam1lZGltYSIsImEiOiJjbDMxMjRzbGgxcnZlM2pvNW0wN2cyNG5sIn0.RM6BTvc52R99Oohk8nXEqg';
    // This GeoJSON contains features that include an "icon"
    // property. The value of the "icon" property corresponds
    // to an image in the Mapbox Light style's sprite. (Note:
    // the name of images is the value of the "icon" property
    // + "-15".)
    const places = drupalSettings.mapbox;
    console.log(places);

    const filterGroup = document.getElementById('filter-group');
    const map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/outdoors-v11',
        center: [-3.703339, 40.416729],
        zoom: 4
    });

    map.on('load', () => {
        // Add a GeoJSON source containing place coordinates and information.
        map.addSource('places', {
            'type': 'geojson',
            'data': places
        });

        for (const feature of places.features) {
            const symbol = feature.properties.icon;
            console.log(feature.properties.image);
            map.loadImage(feature.properties.image,
                (error, image) => {
                    if (error) throw error;
                    map.addImage(symbol, image);
                    console.log(image);
                    
                }
            );
            const layerID = `poi-${symbol}`;
            
            // Add a layer for this symbol type if it hasn't been added already.
            if (!map.getLayer(layerID)) {
                map.addLayer({
                    'id': layerID,
                    'type': 'symbol',
                    'source': 'places',
                    'layout': {
                        // These icons are a part of the Mapbox Light style.
                        // To view all images available in a Mapbox style, open
                        // the style in Mapbox Studio and click the "Images" tab.
                        // To add a new image to the style at runtime see
                        // https://docs.mapbox.com/mapbox-gl-js/example/add-image/
                        'icon-image': symbol,
                        'icon-allow-overlap': true
                    },
                    'filter': ['==', 'icon', symbol]
                });
                

                // Add checkbox and label elements for the layer.
                const input = document.createElement('input');
                input.type = 'checkbox';
                input.id = layerID;
                input.checked = true;
                filterGroup.appendChild(input);

                const label = document.createElement('label');
                label.setAttribute('for', layerID);
                label.textContent = symbol;
                filterGroup.appendChild(label);

                // When the checkbox changes, update the visibility of the layer.
                input.addEventListener('change', (e) => {
                    map.setLayoutProperty(
                        layerID,
                        'visibility',
                        e.target.checked ? 'visible' : 'none'
                    );
                });
            }
        }
    });
})(jQuery, Drupal, drupalSettings);
<?php

namespace Drupal\cb_user\Plugin\rest\resource;

use Drupal\rest\ModifiedResourceResponse;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Provides a resource to get view modes by entity and bundle.
 *
 * @RestResource(
 *   id = "user_created_rest",
 *   label = @Translation("User created rest"),
 *   uri_paths = {
 *     "create" = "/api/user/create"
 *   }
 * )
 */
class UserCreatedRest extends ResourceBase {

  /**
   * A current user instance.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  protected $currentUser;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $instance->currentUser = $container->get('current_user');
    return $instance;
  }

    /**
     * Responds to POST requests.
     *
     * @param string $payload
     *
     * @return \Drupal\rest\ModifiedResourceResponse
     *   The HTTP response object.
     *
     * @throws \Symfony\Component\HttpKernel\Exception\HttpException
     *   Throws exception expected.
     */
    public function post($data) {
      
      // You must to implement the logic of your REST Resource here.
      // Use current user after pass authentication to validate access.
      if (!$this->currentUser->hasPermission('access content')) {
          throw new AccessDeniedHttpException();
      }
      $result = $this->userCreate($data);
      return new ModifiedResourceResponse($result, 200);
    }

    private function userCreate(array $data) {
      $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
      $user = \Drupal\user\Entity\User::create();

      //Mandatory settings
      $user->setPassword($data['password']);
      $user->enforceIsNew();
      $user->setEmail($data['email']);
      $user->setUsername($data['name']); //This username must be unique and accept only a-Z,0-9, - _ @ .

      //Optional settings
      $user->set("init", 'email');
      $user->set("langcode", $language);
      $user->set("preferred_langcode", $language);
      $user->set("preferred_admin_langcode", $language);
      
      $user->activate();

      try {

        $user_data = [
          'name' => $data['name'],
          'password' => $data['password'],
          'email' => $data['email'],
          'first_name' => $data['first_name'],
          'last_name' => $data['last_name']
        ];
        $crm = \Drupal::service('cb_user.client_cmr');
        $crm->setUserCrm($user_data);

        return (bool) $user->save();
      } catch (\Throwable $th) {
        return (bool) 0;
      }

      //Save user
      
    }

}

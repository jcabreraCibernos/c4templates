<?php

namespace Drupal\cb_flag\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\Core\Entity\EntityPublishedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Flag cb entity entities.
 *
 * @ingroup cb_flag
 */
interface FlagCbEntityInterface extends ContentEntityInterface, EntityChangedInterface, EntityPublishedInterface, EntityOwnerInterface {

  /**
   * Add get/set methods for your configuration properties here.
   */

  /**
   * Gets the Flag cb entity name.
   *
   * @return string
   *   Name of the Flag cb entity.
   */
  public function getName();

  /**
   * Sets the Flag cb entity name.
   *
   * @param string $name
   *   The Flag cb entity name.
   *
   * @return \Drupal\cb_flag\Entity\FlagCbEntityInterface
   *   The called Flag cb entity entity.
   */
  public function setName($name);

  /**
   * Gets the Flag cb entity creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Flag cb entity.
   */
  public function getCreatedTime();

  /**
   * Sets the Flag cb entity creation timestamp.
   *
   * @param int $timestamp
   *   The Flag cb entity creation timestamp.
   *
   * @return \Drupal\cb_flag\Entity\FlagCbEntityInterface
   *   The called Flag cb entity entity.
   */
  public function setCreatedTime($timestamp);

}

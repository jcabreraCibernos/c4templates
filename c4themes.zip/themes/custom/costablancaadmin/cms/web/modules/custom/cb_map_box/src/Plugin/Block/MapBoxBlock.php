<?php

namespace Drupal\cb_map_box\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'MapBoxBlock' block.
 *
 * @Block(
 *  id = "map_box_block",
 *  admin_label = @Translation("Map box block"),
 * )
 */
class MapBoxBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Drupal\Core\File\FileUrlGeneratorInterface definition.
   *
   * @var \Drupal\Core\File\FileUrlGeneratorInterface
   */
  protected $fileUrlGenerator;

  /**
   * Drupal\Core\Entity\EntityTypeManagerInterface definition.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * array definition.
   *
   * @var array
   */
  protected $tid;

  /**
   * string definition.
   *
   * @var string
   */
  protected $vocabulary = 'section';

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static($configuration, $plugin_id, $plugin_definition);
    $instance->fileUrlGenerator = $container->get('file_url_generator');
    $instance->entityTypeManager = $container->get('entity_type.manager');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
    ] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {

    $form['term'] = [
      '#type' => 'select',
      '#title' => $this->t('Taxonomy term'),
      '#options' => $this->filterTaxonomy(),
      '#default_value' => $this->configuration['term'],
      '#weight' => '0',
      '#multiple' => TRUE,
    ];

    $form['filter'] = [
      '#type' => 'radios',
      '#title' => $this->t('Show Filter'),
      '#options' => ['Disable', 'Enable'],
      '#default_value' => $this->configuration['filter'],
      '#weight' => '0',
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['term'] = $form_state->getValue('term');
    $this->configuration['filter'] = $form_state->getValue('filter');
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    
    $build['#attached']['library'][] = 'cb_map_box/cb_map_box';
    $this->tid = $this->configuration['term'];
    $build['#attached']['drupalSettings']['mapbox'] = $this->getConfig();
    
    $build['#filter'] = $this->configuration['filter'];
    $build['#theme'] = 'map_box_block';
    return $build;
  }

  /**
   * 
   */
  protected function getConfig() {
    $field['type'] = 'FeatureCollection';
    
    foreach($this->getprocessData() as $key => $value) {
      $field['features'][] = [
        'type' => 'Feature',
        'properties' => [
          'icon' => $value['name'],
          'image' => $value['image']
        ],
        'geometry' => [
          'type' => 'Point',
          'coordinates' => [
              $value['lng'],
              $value['lat']
            ] 
        ]
      ];
      
    }  

    return $field;
  }

  protected function getprocessData() {
    $tid = $this->configuration['term'];
    
    $result = [];
    $ids = \Drupal::entityQuery('node')
      ->condition('type', 'page')
      ->condition('status', 1);
    if (!empty($this->getChildrenTaxonomy($tid)) && $all = $this->getChildrenTaxonomy($tid)) {
      $ids->condition('field_section',$all, 'IN');
    }
    $content_ids = $ids->execute();
    
    $content = $this->entityTypeManager->getStorage('node')
    ->loadMultiple($content_ids);
    
    foreach($content as $key => $value) {
      // Load taxonomy term.
      $term = $value->get('field_section')->entity;
      $file_uri = $term->parent->entity->get('field_image')->entity->getFileUri();
      $path = $this->fileUrlGenerator->generateAbsoluteString($file_uri);
      
      $result[] = [
        'name' =>  $term->getName(),
        'image' => $path,
        'lat' => $value->get('field_map')->getValue()[0]['lat'],
        'lng' => $value->get('field_map')->getValue()[0]['lng']
      ];
      
    }

    return $result;

  }

  protected function filterTaxonomy(): array {
    $output = [];
    $tree = $this->entityTypeManager->getStorage('taxonomy_term')
      ->loadTree($this->vocabulary, 0, 1, TRUE);
    
    foreach ($tree as $term) {
      $output[$term->id()] = $term->getName();
    }
    
    return $output;
  }

  private function getChildrenTaxonomy() {
    $terme_name = [];
    $vid = $this->vocabulary;
    $depth = 1; // 1 to get only immediate children, NULL to load entire tree
    $load_entities = FALSE; // True will return loaded entities rather than ids
    foreach($this->tid as $value) {
      $child_terms = $this->entityTypeManager
        ->getStorage('taxonomy_term')
        ->loadTree($vid, $value, $depth, $load_entities);
      
      foreach ($child_terms as $value_term) {
        $terme_name[$value_term->tid] = $value_term->tid;
      }
    }

    return $terme_name;
  }

}

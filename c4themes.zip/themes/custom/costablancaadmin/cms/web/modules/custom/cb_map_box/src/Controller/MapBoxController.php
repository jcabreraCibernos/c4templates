<?php

namespace Drupal\cb_map_box\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class MapBoxController.
 */
class MapBoxController extends ControllerBase {

  /**
   * Drupal\Core\Entity\EntityTypeManagerInterface definition.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Drupal\Core\Entity\EntityTypeManagerInterface definition.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $fileUrlGenerator;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->entityTypeManager = $container->get('entity_type.manager');
    $instance->fileUrlGenerator = $container->get('file_url_generator');

    return $instance;
  }

  /**
   * Getmapbox.
   *
   * @return string
   *   Return Maps string.
   */
  public function getMapBox() {
    $output = [];
    
    $output['#attached']['library'][] = 'cb_map_box/cb_map_box';
    $output['#attached']['drupalSettings']['mapbox'] = $this->getConfig();
    
    $output['#type'] = 'markup';
   $output['#markup'] = '<div id="map"></div> <nav id="filter-group" class="filter-group"></nav>';
    

    return $output;
  }

  protected function getConfig() {
    
    
    $field['type'] = 'FeatureCollection';
    
    foreach($this->getprocessData() as $key => $value) {
      $field['features'][] = [
        'type' => 'Feature',
        'properties' => [
          'icon' => $value['name'],
          'image' => $value['image']
        ],
        'geometry' => [
          'type' => 'Point',
          'coordinates' => [
              $value['lng'],
              $value['lat']
            ]
        ]
      ];
      
    }  

    return $field;
  }

  protected function getprocessData() {
    $content = $this->entityTypeManager->getStorage('node')
      ->loadByProperties(['type' => 'article']);
    
    foreach($content as $key => $value) {
      // Load taxonomy term.
      $term = $value->get('field_section')->entity;
      $file_uri = $term->get('field_image')->entity->getFileUri();
      $path = $this->fileUrlGenerator->generateAbsoluteString($file_uri);
      
      $result[] = [
        'name' =>  $term->getName(),
        'image' => $path,
        'lat' => $value->get('field_map')->getValue()[0]['lat'],
        'lng' => $value->get('field_map')->getValue()[0]['lng']
      ];
    }

      return $result;

  }

}

<?php

namespace Drupal\cb_user;
use GuzzleHttp\ClientInterface;

/**
 * Class ClientCmrService.
 */
class ClientCmrService {

  /**
   * GuzzleHttp\ClientInterface definition.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected $httpClient;

  /**
   * Constructs a new ClientCmrService object.
   */
  public function __construct(ClientInterface $http_client) {
    $this->httpClient = $http_client;
  }

  public function setUserCrm($user_data) {
    $userAuth = [
        'user_name' => 'user',
        'password' => md5('bitnami'),
      ];
      $appName = 'My SuiteCRM REST Client';
      $nameValueList = [];
    
      $args = [
        'user_auth' => $userAuth,
        'application' => $appName,
        'name_value_list' => $nameValueList
      ];
    
      $result = $this->restRequest('login',$args);
      // Get session ID.
      $sessId = $result['id'];
      
      $args = [
        'session' => $sessId,
        'module_name' => 'Users',
        'name_value_lists' => [
          "user_name" => $user_data['name'],
          "user_hash"  => $user_data['passwor'],
          "confirm_pwd" => $user_data['passwor'],
          "status" => "Active",
          "last_name" => $user_data['name'],
          "system_generated_password" => 0,
          "sugar_login" => 1,
          "full_name" => $user_data['name'],
          "name" => $user_data['name'],
          "is_admin" => 1,
          "external_auth_only" => 0,
          "receive_notifications" =>1,
          "created_by" => 1,
          "title" => $user_data['name'],
          "email1" => $user_data['email'],
        ]
      ];
      
      $user_load = $this->restRequest('set_entry',$args);
      
      $id_user = $user_load['id'];
    
      $args = [
        "session" => $sessId, 
        "module_name" => "Contacts", 
        "name_value_lists" => 
          [
            "first_name" =>  $user_data['first_name'],
            "email1" => $user_data['email'], 
            "last_name" => $user_data['last_name'],
            "primary_address_country" => "Spain", 
            "assigned_user_name" => $user_data['name'], 
            "assigned_user_id" => $id_user, 
            "newsletter_acceptance_c" => "TRUE", 
            "privacy_acceptance_c" => "TRUE", 
            "lead_source" =>  "Web Site", 
            "newsletter_language_c" => "ES"
          ]      
      ];
      $result = $this->restRequest('set_entry',$args);
      
    
    }
    
    function restRequest($method, $arguments){
    
      $url = "http://80.36.144.146:8087/service/v4_1/rest.php";
    
      $curl = curl_init($url);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
      $post = array(
              "method" => $method,
              "input_type" => "JSON",
              "response_type" => "JSON",
              "rest_data" => json_encode($arguments),
      );
     
      curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
     
      $result = curl_exec($curl);
      
      curl_close($curl);
      return json_decode($result, 1);
  }
}

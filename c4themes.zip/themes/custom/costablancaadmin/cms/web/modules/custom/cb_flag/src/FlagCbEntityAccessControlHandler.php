<?php

namespace Drupal\cb_flag;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the Flag cb entity entity.
 *
 * @see \Drupal\cb_flag\Entity\FlagCbEntity.
 */
class FlagCbEntityAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\cb_flag\Entity\FlagCbEntityInterface $entity */

    switch ($operation) {

      case 'view':
        
        if ($account->id() == 0 && $entity->field_type->value === 'private') {
          return AccessResult::forbidden();
        }
        
        if (!$entity->isPublished()) {
          return AccessResult::allowedIfHasPermission($account, 'view unpublished flag cb entity entities');
        }


        return AccessResult::allowedIfHasPermission($account, 'view published flag cb entity entities');

      case 'update':

        return AccessResult::allowedIfHasPermission($account, 'edit flag cb entity entities');

      case 'delete':

        return AccessResult::allowedIfHasPermission($account, 'delete flag cb entity entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add flag cb entity entities');
  }


}
